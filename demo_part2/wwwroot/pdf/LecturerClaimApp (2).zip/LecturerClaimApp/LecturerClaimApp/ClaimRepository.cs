using System.Collections.Generic;

namespace LoginApp
{
    public static class ClaimRepository
    {
        // List to hold submitted claims
        public static List<ClaimDetail> SubmittedClaims { get; private set; } = new List<ClaimDetail>();

        // Method to add a claim
        public static void AddClaim(ClaimDetail claim)
        {
            SubmittedClaims.Add(claim);
        }
    }
}
