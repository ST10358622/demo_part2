using System.Collections.ObjectModel;
using System.Windows;

namespace LoginApp
{
    public partial class AdminManagerWindow : Window
    {
        public ObservableCollection<ClaimDetail> Claims { get; set; }

        public AdminManagerWindow()
        {
            InitializeComponent();
            LoadClaims();
        }

        private void LoadClaims()
        {
            // Load claims from the repository into the observable collection
            Claims = new ObservableCollection<ClaimDetail>(ClaimRepository.SubmittedClaims);
            ClaimsDataGrid.ItemsSource = Claims;
        }

        private void ApproveSelectedClaims_Click(object sender, RoutedEventArgs e)
        {
            foreach (var claim in Claims)
            {
                if (claim.Approve)
                {
                    claim.Status = "Approved";
                }
            }
            ClaimsDataGrid.Items.Refresh();
            MessageBox.Show("Selected claims have been approved.");
        }

        private void RejectSelectedClaims_Click(object sender, RoutedEventArgs e)
        {
            foreach (var claim in Claims)
            {
                if (claim.Approve)
                {
                    claim.Status = "Rejected";
                }
            }
            ClaimsDataGrid.Items.Refresh();
            MessageBox.Show("Selected claims have been rejected.");
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow loginWindow = new MainWindow();
            loginWindow.Show();
            this.Close();
        }
    }
}
