using System;
using System.Collections.ObjectModel;
using System.Windows;

namespace LoginApp
{
    public partial class LecturerClaimForm : Window
    {
        public ObservableCollection<ClaimDetail> Claims { get; set; }
        public double GrandTotal { get; set; }

        public LecturerClaimForm()
        {
            InitializeComponent();
            Claims = new ObservableCollection<ClaimDetail>();
            this.DataContext = this;
        }

        private void AddClaimDetail_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(ProgrammeInput.Text) ||
                    string.IsNullOrWhiteSpace(ModuleCodeInput.Text) ||
                    string.IsNullOrWhiteSpace(GroupsInput.Text) ||
                    !int.TryParse(HoursInput.Text, out int numberOfHours) ||
                    !double.TryParse(RateInput.Text, out double hourlyRate))
                {
                    MessageBox.Show("Please fill out all fields with valid numbers for hours and rate.", "Input Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                double total = numberOfHours * hourlyRate;

                var claim = new ClaimDetail
                {
                    Programme = ProgrammeInput.Text,
                    ModuleCode = ModuleCodeInput.Text,
                    Groups = GroupsInput.Text,
                    NumberOfHours = numberOfHours,
                    HourlyRate = hourlyRate,
                    Total = total,
                    LecturerName = $"{LecturerName.Text} {LecturerSurname.Text}", // Include Lecturer's name
                    Status = "Pending",
                    ClaimID = Guid.NewGuid().ToString()
                };

                Claims.Add(claim);

                ProgrammeInput.Clear();
                ModuleCodeInput.Clear();
                GroupsInput.Clear();
                HoursInput.Clear();
                RateInput.Clear();

                UpdateGrandTotal();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding claim detail: {ex.Message}");
            }
        }

        private void UpdateGrandTotal()
        {
            GrandTotal = 0;
            foreach (var claim in Claims)
            {
                GrandTotal += claim.Total;
            }
            GrandTotalTextBlock.Text = $"R{GrandTotal:N2}";
        }

        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            // Add claims to the central repository
            foreach (var claim in Claims)
            {
                ClaimRepository.AddClaim(claim);
            }

            MessageBox.Show("Claim Submitted Successfully.");
            Claims.Clear();
            UpdateGrandTotal();
        }

        private void UploadDocuments_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Uploading documents...");
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow loginWindow = new MainWindow();
            loginWindow.Show();
            this.Close();
        }
    }

    public class ClaimDetail
    {
        public string ClaimID { get; set; }
        public string LecturerName { get; set; }
        public string Programme { get; set; }
        public string ModuleCode { get; set; }
        public string Groups { get; set; }
        public int NumberOfHours { get; set; }
        public double HourlyRate { get; set; }
        public double Total { get; set; }
        public string Status { get; set; }
        public bool Approve { get; set; }
    }
}
