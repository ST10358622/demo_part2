﻿using System.Windows;

namespace LoginApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LecturerLogin_Click(object sender, RoutedEventArgs e)
        {
            string employeeNo = EmployeeNoTextBox.Text;

            // Allow any password and validate only based on employee number for lecturer
            if (IsLecturer(employeeNo))
            {
                LecturerClaimForm lecturerWindow = new LecturerClaimForm();
                lecturerWindow.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid Lecturer Employee Number.");
            }
        }

        private void AdminLogin_Click(object sender, RoutedEventArgs e)
        {
            string employeeNo = EmployeeNoTextBox.Text;

            // Allow any password and validate only based on employee number for admin manager
            if (IsAdmin(employeeNo))
            {
                AdminManagerWindow adminWindow = new AdminManagerWindow();
                adminWindow.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid Admin Manager Employee Number.");
            }
        }

        private bool IsLecturer(string employeeNo)
        {
            // Allow any employee number for lecturer
            return true;
        }

        private bool IsAdmin(string employeeNo)
        {
            // Allow any employee number for admin manager
            return true;
        }

    }
}
