﻿namespace demo_part2
{
    public class connection
    {

        //return connection String method

        public String connecting()
        {
            return "Data Source=(localdb)\\demo_p2;Initial Catalog=demo_db;";
        }
    }
}
