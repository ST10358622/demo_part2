﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;

namespace TimeManagementApp
{
    public partial class MainWindow : Window
    {
        public List<Module> modules = new List<Module>();
        public List<Semester> semesters = new List<Semester>(); // Add this list for semesters

        public MainWindow()
        {
            InitializeComponent(); // This line should already be in your constructor

            // Initialize the list of modules
            modules = new List<Module>();

            // Populate the ModuleComboBox
            ModuleComboBox.ItemsSource = modules;
        }

        private void AddModuleButton_Click(object sender, RoutedEventArgs e)
        {
            // Create a new module using the user's input
            Module newModule = new Module
            {
                Code = ModuleCodeTextBox.Text,
                Name = ModuleNameTextBox.Text,
                Credits = int.Parse(CreditsTextBox.Text),
                ClassHours = int.Parse(ClassHoursTextBox.Text)
            };

            // Add the module to the list
            modules.Add(newModule);

            // Update the module list view
            ModuleListView.ItemsSource = modules;

            // Clear the input fields
            ModuleCodeTextBox.Clear();
            ModuleNameTextBox.Clear();
            CreditsTextBox.Clear();
            ClassHoursTextBox.Clear();
        }

        private void AddSemesterButton_Click(object sender, RoutedEventArgs e)
        {
            // Add code here to add semester information
            // For example:
            string numberOfWeeks = SemesterWeeksTextBox.Text;
            string numberOfHours = SemesterHoursTextBox.Text;
            DateTime startDate = StartDatePicker.SelectedDate ?? DateTime.MinValue;
            DateTime endDate = EndDatePicker.SelectedDate ?? DateTime.MinValue;

            // Create a new Semester object and add it to the list
            Semester newSemester = new Semester
            {
                NumberOfWeeks = int.Parse(numberOfWeeks),
                NumberOfHours = int.Parse(numberOfHours),
                StartDate = startDate,
                EndDate = endDate
            };

            // Add the semester to the list
            semesters.Add(newSemester);

            // Clear the input fields
            SemesterWeeksTextBox.Clear();
            SemesterHoursTextBox.Clear();
            StartDatePicker.SelectedDate = null;
            EndDatePicker.SelectedDate = null;

            // Update the semester list view
            SemesterListView.ItemsSource = null; // Clear the binding
            SemesterListView.ItemsSource = semesters; // Rebind to the updated list
        }


        private void RecordHoursButton_Click(object sender, RoutedEventArgs e)
        {
            if (ModuleComboBox.SelectedItem is Module selectedModule &&
                int.TryParse(RecordedHoursTextBox.Text, out int recordedHours))
            {
                // Update the recorded hours for the selected module
                selectedModule.RecordedHours += recordedHours;

                // Calculate the remaining self-study hours for the current week
                DateTime currentDate = RecordDateDatePicker.SelectedDate ?? DateTime.MinValue;
                int currentWeek = CultureInfo.CurrentCulture.Calendar.GetWeekOfYear(currentDate, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Sunday);
                int remainingHours = selectedModule.SelfStudyHoursPerWeek - selectedModule.RecordedHours;

                // Display the remaining hours in the UI
                MessageBox.Show($"Remaining self-study hours for {selectedModule.Name} in week {currentWeek}: {remainingHours}");
            }
            else
            {
                // Handle invalid input
                MessageBox.Show("Invalid input. Please check your selection and recorded hours.");
            }
        }

        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(WeeksTextBox.Text, out int numberOfWeeks))
            {
                // Successfully parsed the input as an integer

                // Calculate and update self-study hours for all modules
                foreach (Module module in modules)
                {
                    if (numberOfWeeks - module.ClassHours > 0)
                    {
                        module.SelfStudyHoursPerWeek = (module.Credits * 10) / (numberOfWeeks - module.ClassHours);
                    }
                    else
                    {
                        module.SelfStudyHoursPerWeek = 0;
                    }

                    // Calculate and update remaining self-study hours for all modules (TODO: Implement recording hours)
                    int recordedHoursForModule = 0; // Replace this with the recorded hours
                    module.SelfStudyHoursRemaining = (module.SelfStudyHoursPerWeek * (numberOfWeeks - module.ClassHours)) - recordedHoursForModule;
                }

                // Refresh the module list view
                ModuleListView.Items.Refresh();
            }
            else
            {
                // Handle the case where the input is not a valid integer
                MessageBox.Show("Please enter a valid number of weeks.");
            }
        }

    }

    public class Semester
    {
        public int NumberOfWeeks { get; set; }
        public int NumberOfHours { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }

    public class Module
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public int Credits { get; set; }
        public int ClassHours { get; set; }
        public int SelfStudyHoursPerWeek { get; set; }
        public int SelfStudyHoursRemaining { get; set; }

        // Add a property to record hours worked
        public int RecordedHours { get; set; }
    }
}
