﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using TimeManagementApp.Data;

namespace TimeManagementApp
{
    public partial class TimeManagementHelper : Window
    {
        private readonly UserService userService;
        private readonly ApplicationDbContext dbContext;

        public TimeManagementHelper()
        {
            InitializeComponent();

            // Initialize the database context
            dbContext = new ApplicationDbContext();

            userService = new UserService(dbContext);
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (textBox.Foreground == Brushes.Gray)
            {
                textBox.Text = "";
                textBox.Foreground = Brushes.Black;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "Your placeholder text";
                textBox.Foreground = Brushes.Gray;
            }
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;

            try
            {
                userService.Register(username, password);
                MessageBox.Show("Registration successful.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (DbUpdateException)
            {
                MessageBox.Show("Registration failed: A database error occurred. Please check your database configuration.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Registration failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = LoginUsernameTextBox.Text;
            string password = LoginPasswordBox.Password;

            if (userService.AuthenticateUserAsync(username, password)) // Replace with your actual authentication method
            {
                MessageBox.Show("Login successful.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                // Implement code to proceed with the main application functionality.
            }
            else
            {
                MessageBox.Show("Login failed. Check your credentials.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private class UserService
        {
            private ApplicationDbContext dbContext;

            public UserService(ApplicationDbContext dbContext)
            {
                this.dbContext = dbContext;
            }

            internal bool AuthenticateUserAsync(string username, string password)
            {
                throw new NotImplementedException();
            }

            internal void Register(string username, string password)
            {
                throw new NotImplementedException();
            }
        }
    }
}
