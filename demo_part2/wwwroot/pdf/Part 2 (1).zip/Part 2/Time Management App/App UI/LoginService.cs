﻿using Microsoft.EntityFrameworkCore;
using BCrypt.Net;
using System.Threading.Tasks;
using TimeManagementApp.Data;

namespace TimeManagementApp.Services
{
    public class LoginService
    {
        public async Task<User?> AuthenticateUserAsync(string username, string password)
        {
            using (var context = new ApplicationDbContext())
            {
                var user = await context.Users.SingleOrDefaultAsync(u => u.Username == username);

                if (user != null && BCrypt.Net.BCrypt.Verify(password, user.PasswordHash))
                {
                    return user; // Authentication successful
                }

                return null; // Authentication failed
            }
        }
    }
}
