﻿public class YourDataModel
{
    public int Id { get; set; }
    public string SomeData { get; set; }
    public int UserId { get; set; }
    public User User { get; set; }
}

