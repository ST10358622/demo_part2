﻿using System;

namespace TimeManagementLibrary
{
    public class SemesterInfo
    {
        public int NumberOfWeeks { get; set; }
        public DateTime StartDate { get; set; }
    }
}

