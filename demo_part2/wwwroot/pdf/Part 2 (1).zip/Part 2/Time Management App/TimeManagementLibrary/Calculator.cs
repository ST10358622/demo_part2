﻿using System;

namespace TimeManagementLibrary
{
    public class Calculator
    {
        public int CalculateSelfStudyHours(Module module, SemesterInfo semester)
        {
            // Implement the self-study hour calculation here.
            return module.Credits * 10 - module.ClassHoursPerWeek * semester.NumberOfWeeks;
        }
    }
}

